from centralplatform.File1 import *
from centralplatform.Dept import *
